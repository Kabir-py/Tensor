# lighter > 2024-02-19 5:14pm
https://universe.roboflow.com/vision-wajsm/lighter-wvso3

Provided by a Roboflow user
License: CC BY 4.0

